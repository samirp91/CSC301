package edu.toronto.csc301.impl;

import java.awt.image.RenderedImage;
import java.io.EOFException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.Iterator;

import edu.toronto.csc301.IPost;
import edu.toronto.csc301.ISerializer;
import edu.toronto.csc301.IUser;
import edu.toronto.csc301.IUserStore;
import edu.toronto.csc301.Util;


public class Serializer implements ISerializer{
	private IUserStore userstore = new UserStore();
	@Override
	public void serialize(IUser user, OutputStream output) throws Exception {
		// TODO Auto-generated method stub
		ObjectOutputStream out = new ObjectOutputStream(output);
		serialize2(user, out);
		
		
	}

	private void serialize2(IUser user, ObjectOutputStream out) throws Exception {
		// TODO Auto-generated method stub
		String username = user.getUsername();
		String password = user.getPassword();
		try{
			userstore.createUser(username, password);
			LocalDateTime registrationTime = user.getRegistrationTime();
			Iterator<IPost> postArray = user.getPosts();
			Iterator<IPost> likedPosts = user.getLikes();
			out.writeObject(username);
			out.writeObject(password);
			out.writeObject(registrationTime);
			serialize(postArray, out);
//			String postType = "Liked";
//			out.writeObject(postType);
//			serialize(likedPosts, out);
		}
		catch (Exception e){
			
		}
		
//		serialize3(likedPosts, out);
		
		
	}
	
	

	private void serialize3(Iterator<IPost> likedPosts, ObjectOutputStream out) throws Exception {
		while (likedPosts.hasNext()){
			IPost post = likedPosts.next();
			String caption = post.getCaption();
			RenderedImage image = post.getImage();
			LocalDateTime postedAt = post.getPostedAt();
			IUser user = post.getPostedBy();
			byte[] imageBytes = Util.imageToByteArray(image);
			int size = imageBytes.length;
			String postString = "Likes";
			out.writeObject(caption);
			out.writeInt(size);
			out.write(imageBytes);
			out.writeObject(postedAt);
			out.writeObject(postString);
			serialize2(user, out);
		}
		
	}

	private void serialize(Iterator<IPost> postArray, ObjectOutputStream out) throws Exception {
		while (postArray.hasNext()){
			IPost post = postArray.next();
			String caption = post.getCaption();
			RenderedImage image = post.getImage();
			LocalDateTime postedAt = post.getPostedAt();
			Iterator<IUser> likes = post.getLikes();
			byte[] imageBytes = Util.imageToByteArray(image);
			int size = imageBytes.length;
			String postString = "Post";
			out.writeObject(postString);
			out.writeObject(caption);
			out.writeInt(size);
			out.write(imageBytes);
			out.writeObject(postedAt);
//			while (likes.hasNext()){
//				IUser user2 = likes.next();
//				String likesString = "Likes";
//				out.writeObject(likesString);
//				serialize2(user2, out);
//			}
		}
		
	}

	@Override
	public IUser deserializeUser(InputStream input) throws Exception {
		if (input == null){
			throw new NullPointerException();
		}
		ObjectInputStream in = new ObjectInputStream(input);
		IUser user = null;
		user = deserializeUser2(in, user);
		
		
		return user;
	}
	
	private IUser deserializeUser2(ObjectInputStream in, IUser user) throws Exception {
		// TODO Auto-generated method stub
		try{
			while (true){
				String username = (String) in.readObject();
				String password = (String) in.readObject();
				LocalDateTime registrationTime = (LocalDateTime) in.readObject();
				user = new User(username, password);
				user.setRegistrationTime(registrationTime);
				String postType = (String) in.readObject();
				deserializePost(in, user, postType);
			}
		}
		catch (EOFException e){
//			e.printStackTrace();
		}
		return user;
	}
	private IUser user;
	
	public void deserializePost(ObjectInputStream in, IUser user, String postType) throws Exception {
		IPost post = null;
		while (true) {
			if (postType.equals("Likes")){
				IUser user2;
				String username = (String) in.readObject();
				String password = (String) in.readObject();
				LocalDateTime registrationTime = (LocalDateTime) in.readObject();
				postType = (String) in.readObject();
				user2 = new User(username, password);
				user2.setRegistrationTime(registrationTime);
				post.addLike(user2);				
			}
			else if (postType.equals("Post")){
				String caption = (String) in.readObject();
				int size = in.readInt();
				byte[] imageBytes = new byte[size];
				in.read(imageBytes);
				RenderedImage image = Util.byteArrayToImage(imageBytes);
				LocalDateTime postedAt = (LocalDateTime) in.readObject();
				post = new Post(image, caption);
				post.setPostedAt(postedAt);
				user.newPost(image, caption).setPostedAt(postedAt);
				postType = (String) in.readObject();
			}
			else{
				postType = (String) in.readObject();
				if (postType.equals("Post")){
					String caption = (String) in.readObject();
					int size = in.readInt();
					byte[] imageBytes = new byte[size];
					in.read(imageBytes);
					RenderedImage image = Util.byteArrayToImage(imageBytes);
					LocalDateTime postedAt = (LocalDateTime) in.readObject();
					post = new Post(image, caption);
					post.setPostedAt(postedAt);
					post.addLike(user);
				}
				else if (postType.equals("Likes")){
					IUser user2;
					String username = (String) in.readObject();
					String password = (String) in.readObject();
					LocalDateTime registrationTime = (LocalDateTime) in.readObject();
					postType = (String) in.readObject();
					user2 = new User(username, password);
					user2.setRegistrationTime(registrationTime);
					user2.like(post);
				}
			}
		}
	}
	

}