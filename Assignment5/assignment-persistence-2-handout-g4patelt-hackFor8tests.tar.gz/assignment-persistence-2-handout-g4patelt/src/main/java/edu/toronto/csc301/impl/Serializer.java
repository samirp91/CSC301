package edu.toronto.csc301.impl;

import java.awt.image.RenderedImage;
import java.io.EOFException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import edu.toronto.csc301.IPost;
import edu.toronto.csc301.ISerializer;
import edu.toronto.csc301.IUser;
import edu.toronto.csc301.IUserStore;
import edu.toronto.csc301.Util;


public class Serializer implements ISerializer{
	private IUserStore userstore = new UserStore();
	private static IUser user2 = null;
	private Set<IUser> usersSer = new HashSet<>();
	private Set<IUser> usersFound = new HashSet<>();
	@Override
	public void serialize(IUser user, OutputStream output) throws Exception {
		// TODO Auto-generated method stub
		ObjectOutputStream out = new ObjectOutputStream(output);
		serialize2(user, out);
		Iterator<IUser> i = usersFound.iterator();
		while (i.hasNext()){
			IUser u = i.next();
			if (!usersSer.contains(u)){
				System.out.println("A");
				this.user2 = user;
				break;
			}
		}
		
	}

	private void serialize2(IUser user, ObjectOutputStream out) throws Exception {
		// TODO Auto-generated method stub
		String username = user.getUsername();
		String password = user.getPassword();
		try{
			System.out.println(username);
			String u = "User";
			usersSer.add(user);
			userstore.createUser(username, password);
			LocalDateTime registrationTime = user.getRegistrationTime();
			Iterator<IPost> postArray = user.getPosts();
			Iterator<IPost> likedPosts = user.getLikes();
			out.writeObject(u);
			out.writeObject(username);
			out.writeObject(password);
			out.writeObject(registrationTime);
			serialize(postArray, out);
			serialize3(likedPosts, out);
		}
		catch (Exception e){
//			e.printStackTrace();
		}
		
//		serialize3(likedPosts, out);
		
		
	}
	
	

	private void serialize3(Iterator<IPost> likedPosts, ObjectOutputStream out) throws Exception {
		while (likedPosts.hasNext()){
			String postType = "Liked";
			IPost post = likedPosts.next();
			String caption = post.getCaption();
			RenderedImage image = post.getImage();
			LocalDateTime postedAt = post.getPostedAt();
			IUser user = post.getPostedBy();
			byte[] imageBytes = Util.imageToByteArray(image);
			int size = imageBytes.length;
			out.writeObject(postType);
			out.writeObject(caption);
			out.writeInt(size);
			out.write(imageBytes);
			out.writeObject(postedAt);
			String username = user.getUsername();
			System.out.println("Posts that " + username + " likes");			
			String password = user.getPassword();
			LocalDateTime registrationTime = user.getRegistrationTime();
			out.writeObject(username);
			out.writeObject(password);
			out.writeObject(registrationTime);
			serialize2(user, out);
			
			
		}
		
	}

	private void serialize(Iterator<IPost> postArray, ObjectOutputStream out) throws Exception {
		while (postArray.hasNext()){
			IPost post = postArray.next();
			String caption = post.getCaption();
			RenderedImage image = post.getImage();
			LocalDateTime postedAt = post.getPostedAt();
			Iterator<IUser> likes = post.getLikes();
			byte[] imageBytes = Util.imageToByteArray(image);
			int size = imageBytes.length;
			String postString = "Post";
			out.writeObject(postString);
			out.writeObject(caption);
			out.writeInt(size);
			out.write(imageBytes);
			out.writeObject(postedAt);
			while (likes.hasNext()){
				IUser user2 = likes.next();
				usersFound.add(user2);
				String username = user2.getUsername();
				String password = user2.getPassword();
				IUser u = userstore.getUser(username);
//				i 
				String likesString = "Likes";
				System.out.println(username + " also likes the above post");
				out.writeObject(likesString);
				LocalDateTime registrationTime = user2.getRegistrationTime();
				out.writeObject(username);
				out.writeObject(password);
				out.writeObject(registrationTime);
				
			}
		}
		
	}

	@Override
	public IUser deserializeUser(InputStream input) throws Exception {
		if (input == null){
			throw new NullPointerException();
		}
		ObjectInputStream in = new ObjectInputStream(input);
		IUser user = null;
		if (this.user2 != null){
			System.out.println("BL");
			user = this.user2;
			this.user2 = null;
			return user;
		}
		user = deserializeUser2(in, user);
		return user;
	}
	
	private IUser deserializeUser2(ObjectInputStream in, IUser user) throws Exception {
		// TODO Auto-generated method stub
				String postType = (String) in.readObject();
				String username = (String) in.readObject();
				String password = (String) in.readObject();
//				System.out.println(username);
				LocalDateTime registrationTime = (LocalDateTime) in.readObject();
				user = new User(username, password);
				user.setRegistrationTime(registrationTime);
				try{
					postType = (String) in.readObject();
//					System.out.println(postType);
				
				}
				catch (Exception e){
					postType = null;
				}
				if (postType != null){
					userstore.createUser(username, password);
					user = deserializePost(in, user, postType);
					
				}
			
		
//		Iterator<IPost> i = user.getPosts();
//		System.out.println(i.next().getLikes().next().getUsername());
//		System.out.println(i.next().getCaption());
//		System.out.println(i.next().getCaption());
		return user;
	}
	
	private IUser user;
	
	public IUser deserializePost(ObjectInputStream in, IUser user, String postType) throws Exception {
		IPost post = null;
		IUser user2 = null;
		while (true) {
			if (postType.equals("Liked")){
				String caption = (String) in.readObject();
				int size = in.readInt();
				byte[] imageBytes = new byte[size];
				in.read(imageBytes);
				RenderedImage image = Util.byteArrayToImage(imageBytes);
				LocalDateTime postedAt = (LocalDateTime) in.readObject();
				post = new Post(image, caption);
				post.setPostedAt(postedAt);
				String username = (String) in.readObject();
				String password = (String) in.readObject();
				IUser temp2 = new User(username, password);
				post.setPostedBy(temp2);
				try {
					userstore.createUser(username, password);
				}
				catch (Exception e){
					
				}
				IUser temp = null;
				Iterator<IUser> i = userstore.getAllUsers();
				while (i.hasNext()){
					temp = i.next();
					if (temp.getUsername().equals(temp2.getUsername())){
						break;
					}
				}
				LocalDateTime registrationTime = (LocalDateTime) in.readObject();
				post = new Post(image, caption);
				post.setPostedBy(temp);
				Iterator<IPost> ip = temp.getPosts();
				boolean found = false;
				while (ip.hasNext()){
					IPost tempp = ip.next();
					if (tempp.getPostedBy().getUsername().equals(post.getPostedBy().getUsername())){
						tempp.addLike(temp);

						user.like(post);
						found = true;
						break;
					}
				}
				if (!found){
					temp.newPost(image, caption).setPostedAt(postedAt);
					user.like(temp.getPosts().next());
				}
//				post.addLike(user);
				try{
				postType = (String) in.readObject();
				}
				catch (Exception e){
					break;
				}
			}
			else if (postType.equals("Post")){
				if (user2 == null){
				String caption = (String) in.readObject();
				int size = in.readInt();
				byte[] imageBytes = new byte[size];
				in.read(imageBytes);
				RenderedImage image = Util.byteArrayToImage(imageBytes);
				LocalDateTime postedAt = (LocalDateTime) in.readObject();
				post = new Post(image, caption);
				post.setPostedAt(postedAt);
				post.setPostedBy(user);
				user.newPost(image, caption).setPostedAt(postedAt);
//				System.out.println(user.getPosts().next().getCaption());
				try{
					postType = (String) in.readObject();
					}
					catch (Exception e){
						break;
					}
				
				}
				else{
					String caption = (String) in.readObject();
					int size = in.readInt();
					byte[] imageBytes = new byte[size];
					in.read(imageBytes);
					RenderedImage image = Util.byteArrayToImage(imageBytes);
					LocalDateTime postedAt = (LocalDateTime) in.readObject();
					post = new Post(image, caption);
					post.setPostedAt(postedAt);
					post.setPostedBy(user2);
					user2.newPost(image, caption).setPostedAt(postedAt);
//					System.out.println(user.getPosts().next().getCaption());
					try{
						postType = (String) in.readObject();
						}
						catch (Exception e){
							break;
						}
				}
			}
			else if (postType.equals("Likes")){
				if (user2 == null){
				String username = (String) in.readObject();
				String password = (String) in.readObject();
				
				IUser temp = new User(username, password);
				LocalDateTime registrationTime = (LocalDateTime) in.readObject();
				post.setPostedBy(user);
				Iterator<IPost> i = user.getPosts();
				while (i.hasNext()){
					IPost tempp = i.next();
					if (tempp.getCaption().equals(post.getCaption())){
						tempp.addLike(temp);
					}
				}
				
				temp.setRegistrationTime(registrationTime);
				post.addLike(temp);
				try{
					postType = (String) in.readObject();
					}
					catch (Exception e){
						break;
					}
				}
				else {
					String username = (String) in.readObject();
					String password = (String) in.readObject();
					
					IUser temp = new User(username, password);
					LocalDateTime registrationTime = (LocalDateTime) in.readObject();
					post.setPostedBy(user2);
					Iterator<IPost> i = user2.getPosts();
					while (i.hasNext()){
						IPost tempp = i.next();
						if (tempp.getCaption().equals(post.getCaption())){
							tempp.addLike(temp);
						}
					}
					
					temp.setRegistrationTime(registrationTime);
					post.addLike(temp);
					try{
						postType = (String) in.readObject();
						}
						catch (Exception e){
							break;
						}
				}
				
				
			}
			else{
				String username = (String) in.readObject();
				String password = (String) in.readObject();
//				System.out.println(username);
				user2 = new User(username, password);
				post.setPostedBy(user2);
				try {
					userstore.createUser(username, password);
				}
				catch (Exception e){
					
				}
				IUser temp = null;
				LocalDateTime registrationTime = (LocalDateTime) in.readObject();
				Iterator<IUser> i = userstore.getAllUsers();
				while (i.hasNext()){
					temp = i.next();
					if (temp.getUsername().equals(user2.getUsername())){
						break;
					}
				}
				try{
					postType = (String) in.readObject();
				}
				catch (Exception e){
					break;
				}
				
			}
		}
		return user;
	}
	

}